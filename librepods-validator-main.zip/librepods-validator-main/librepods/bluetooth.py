"""Bluetooth stack detection utilities."""

import os
import subprocess


def check_stack() -> bool:
    """Return True if a Bluetooth stack is reachable on this machine."""
    for path in ("/sys/class/bluetooth", "/proc/net/bluetooth"):
        if os.path.exists(path):
            return True
    try:
        r = subprocess.run(
            ["bluetoothctl", "--version"],
            capture_output=True,
            timeout=3,
        )
        return r.returncode == 0
    except Exception:
        return False
